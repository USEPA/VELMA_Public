#  Command line for gathering info for processing and generating initial spatial pools
#  9-11-2018
#  Author: Paul Pettus
#  Spatial_Pools_CommandLine.py
#
#  2-21-202
#  Python 3 conversions: Kevin Djang
#  1. Changed all "xrange(" calls to "range(", per Python 3 requirements.
#  2. Changed all "time.clock()" call to "time.perf_counter()", per "Deprecation Warning" suggestion.
#  3. Encapsulated time-elapsed messaging into print_elapsed_message() function.

import time
import csv
import os, sys, argparse
import numpy
import linecache

# Error message class
class Usage(Exception):
    def __init__(self, msg):
        self.msg = msg

# Main class
def main(argv=None):

    if argv is None:
        argv = sys.argv

    try:
        # Describe the tool and required aruments
        parser = argparse.ArgumentParser(description='Outputs spatial chemistry disturbance pools from an'+
                                         ' above ground biomass file layer input and a ratio file.')

        # Ratio file input
        parser.add_argument('-Rat', action='store', dest='ratioFILE',                    
                            help='Fully-qualified path + name of ".csv" biomass ratio file.')

        # Biomass ascii file input
        parser.add_argument('-Bio', action='store', dest='biomassFILE',
                            help='Fully-qualified path + name of ".asc" biomass file.')

        # Biomass ascii file input
        parser.add_argument('-Con', action='store', dest='conFILE',
                            help='Fully-qualified path + name of ".csv" driver file.')

        # Age ascii file input
        parser.add_argument('-Age', action='store', dest='ageFILE',
                            help='Fully-qualified path + name of ".asc" age file.')

        # Maximum biomass value per cell
        parser.add_argument('-Max', action='store', dest='maxBio',
                            help='Maximum biomass/age value per cell (g/m2 or years) default is 62000g/m2 or 400 years.')

        # Minimum biomass value per cell
        parser.add_argument('-Min', action='store', dest='minBio',
                            help='Minimum biomass/age value per cell (g/m2 or years), default is 400g/m2 or 1 year.')

### Minimum biomass value per cell
##        parser.add_argument('-Min', action='store', metavar='minBio',
##                            type=int,
##                            help='Minimum biomass/age value per cell (g/m2 or years), default is 400g/m2 or 1 year.')

        # Output dir for spatial chemistry pools
        parser.add_argument('-Out', action='store', dest='outDIR',
                            help='Fully-qualified path directory for the output pool files.')
        
        args = parser.parse_args()

        # args parsing
        if args.ratioFILE == None:
            ratioFile = args.ratioFILE
        else:
            ratioFile = str(os.path.abspath(args.ratioFILE))

        if args.biomassFILE == None:
            biomassFile = args.biomassFILE
        else:
            biomassFile = str(os.path.abspath(args.biomassFILE))

        if args.conFILE == None:
            conFile = args.conFILE
        else:
            conFile = str(os.path.abspath(args.conFILE))

        if args.ageFILE == None:
            ageFile = args.ageFILE
        else:
            ageFile = str(os.path.abspath(args.ageFILE))

        outDir = str(os.path.abspath(args.outDIR)) + "\\"

        if args.minBio == None:
            minValArg = args.minBio
        else:
            minValArg = int(args.minBio)
        
        if args.maxBio == None:
            maxValArg = args.maxBio
        else:
            maxValArg = int(args.maxBio)

                # Print all input arguments
        print('\n' + '\n' + "Echo inputs" + '\n')
##        print(args)
##        print('\n')

        print(outDir, ratioFile, biomassFile, conFile, ageFile, minValArg, maxValArg)
        
        # do the work function
        buildRatios(outDir, ratioFile, biomassFile, conFile, ageFile, minValArg, maxValArg)

    except Usage as e:
        print(e.msg)
        return 2
    
    except Exception as e:
        # STUB exception handler
        # Warning: poor programming style.
        # Catches almost any exception (but not KeyboardInterrupt -- which is a Good Thing)
        raise e

## Return an numpy array from an ascii raster
def ascii2array(asciifn):
#### GDAL version    
##    dsAscii = gdal.Open(asciifn,gdalconst.GA_ReadOnly)
##    cols = dsAscii.RasterXSize
##    rows = dsAscii.RasterYSize
##    bands = dsAscii.RasterCount
##    band = dsAscii.GetRasterBand(1)
    array = numpy.loadtxt(asciifn, skiprows=6, dtype= numpy.float32)
    return array

## Return and ascii raster file from an numpy array, output file name
## (optional inputs are an alternative ascii area of interest and or
## an optional header text: these are not used in the script
def array2ascii(array, asciiOutfn, asciiaoi = None, headerList = None):

    # set up header text for the output ascii raster
    if asciiaoi == None:
##        for i in headerList:
        header = headerList
    else:
        header = linecache.getline(asciiaoi,1)
        header += linecache.getline(asciiaoi,2)
        header += linecache.getline(asciiaoi,3)
        header += linecache.getline(asciiaoi,4)
        header += linecache.getline(asciiaoi,5)
        header += linecache.getline(asciiaoi,6)

    # open the output file and write the header text and numpy array
    # and save the output file
    f = open(asciiOutfn, "w")
    f.write(header)
    numpy.savetxt(f, array, fmt="%f")
    f.close()

## return the header information of an ascii raster
def readHeader(asciiFile):

    # return error if the ascii is not found
    if not os.path.exists(asciiFile):
        raise Usage('Cannot find ASCII "' + asciiFile + '"')

    # Open file and read in header info
    readFile = open(asciiFile)

    header = readFile.readline()  #ncols
    header += readFile.readline() #nrows
    header += readFile.readline() #xllcorner
    header += readFile.readline() #yllcorner
    header += readFile.readline() #cellsize
    header += readFile.readline() #NODATA_value
    readFile.close()

    return header

# Do the work class, build the ratio files
def buildRatios(finalPoolDir, ratioFile, biomassFile, conFile, ageFile, minValArg, maxValArg):

    ##################################################################################
    # Start preprocess code block
    ##################################################################################
    
    # return error if the ratio file is not found
    if not os.path.exists(ratioFile):
        raise Usage('Cannot find ratio file "' + ratioFile + '"')

    # return error if both the age or biomass asciis are arguments
    if ageFile != None and biomassFile != None:
        print(ageFile)
        print(biomassFile)
        raise Usage('Please choose either a biomass or an age ASCII raster, not both.')
        
    # return error if the age or biomass ascii is not found
    if ageFile == None:
        # return error if the biomass ascii is not found
        print("Calculating chemistry pool rasters from biomass raster."+ '\n')
##        print("hello")
##        print(biomassFile)
        if not os.path.exists(biomassFile):
            raise Usage('Cannot find biomass ASCII "' + biomassFile + '\n')
    else:
        print("Calculating chemistry pool rasters from age raster."+ '\n')
        if not os.path.exists(ageFile):
            raise Usage('Cannot find age ASCII "' + ageFile + '"')

##    # return error if the biomass ascii is not found
##    if not os.path.exists(biomassFile):
##        raise Usage('Cannot find conversion driver file "' + conFile + '"')

    # create the output dir if it doesn't exist
    if not os.path.exists(os.path.dirname(finalPoolDir)):
        print("Final outpur dir not found, creating it."+ '\n')
        # Safety bachslash to slash replacement
        finalPoolDir.replace("\\",'/')
        os.makedirs(os.path.dirname(finalPoolDir))

    # Set maximum and minimum biomass value
    if biomassFile != None:
        print(biomassFile)
        # Set default maximum and minimum biomass value
        if maxValArg == None:
            maxValue = 62000
        else:
            maxValue = maxValArg
            
        if minValArg == None:
            minValue = 400
        else:
            minValue = minValArg

    # Set maximum and minimum age value
    if ageFile != None:
        
        # Set default maximum and minimum age value
        if maxValArg == None:
            maxValue = 400
        else:
            maxValue = maxValArg
            
        if minValArg == None:
            minValue = 0
        else:
            minValue = minValArg

        # Check to that maxValue isn't larger than length of ratio lookup
        ratioLookupArray = numpy.genfromtxt(ratioFile,skip_header=1, dtype=float, delimiter=',')
        rCount, cCount = ratioLookupArray.shape
        if int(maxValue) > int(rCount):
            raise Usage('Max age is larger than ratio file rows ' + str(rCount))

    print(maxValue)
    print(minValue)

    # numpy method to read .csv to array
    ratioLookupArray = numpy.genfromtxt(ratioFile,skip_header=1, dtype=float, delimiter=',')

    # Read biomass or age raster to array
    if ageFile != None:
        # Read age raster to array
        ageArray = ascii2array(ageFile)
        # get the ascii raster header information
        buildRatios.header = readHeader(ageFile)
    else:
        # Read biomass to array
        biomassArray = ascii2array(biomassFile)
        # get the ascii raster header information
        buildRatios.header = readHeader(biomassFile)
        
    # read through ratio conversion driver file
    datafile = open(conFile, 'r')
    next(datafile,None)
    myreader = csv.reader(datafile)
    # create ratio conversion to a list
    driverList = list(myreader)
    # close file
    datafile.close()


    ##################################################################################
    # End preprocess code block
    ##################################################################################

    ##################################################################################
    # Start functions block
    ##################################################################################

    # Function: Returns grams of carbon for the upper and lower most
    # biomass lookup cells.  These two cells do not need to dynamically
    # calculated.
    # Inputs:
    # upval = the lookup ratio
    # cellmass = biomass cell value
    # Output:
    # gramsC = grams of carbon
    def calLowHighper(upval,cellmass):
        gramsC = upval*cellmass
        return gramsC
        
    # Function: Dynamically returns grams of carbon from the larger and smaller
    # biomass lookup cells.  Creates fraction difference between a larger
    # and smaller biomass value in the biomass lookup table, then applies that
    # fraction value difference to the lookup attribute.
    # Inputs:
    # smallMass = smaller biomass from the velma attribute array
    # largeMass = larger biomass from the velma attribute array
    # upval = the lookup ratio that corresponds to the largeMass value
    # lowval= the lookup ratio that corresponds to the smallMass value
    # cellmass = biomass cell value
    # Output:
    # gramsC = grams of carbon
    # Variables:
    # difmass = difference bewteen the large and small biomass
    # permass = fraction of cellmass that is over the smallMass
    # difval = difference between upval and lowval
    # deltaRatioValue = corresponding fraction of the lookup value
    # newValue = the correct ratio of the the lookup value
    # gramsC = grams of carbon
    def calMidper(upval,lowval,largeMass,smallMass,cellmass):
        difmass = (largeMass-smallMass)
        permass = (cellmass-smallMass)/difmass
        difval = (upval-lowval)
        # If the difval is negative then lowval is larger than upval.
        if difval < 0:
            difval = (lowval-upval)
            deltaRatioValue = permass*difval
            newValue = (lowval-deltaRatioValue) 
            gramsC = cellmass*newValue
            return gramsC
        elif difval == 0:
            gramsC = cellmass*upval
            return gramsC
        # Else: upval is larger than lowval
        else:
            deltaRatioValue = permass*difval
            newValue = deltaRatioValue+lowval 
            gramsC = cellmass*newValue
            return gramsC

    # Function: For each cell in biomass raster, lookup its biomass in the biomass ratio lookup
    # table and calculate a new grams of carbon value.  Returns an array that can be turned back
    # into a new raster for any inputed velma attribute.
    # Inputs:
    # biomassArray = input biomass array, from biomass raster
    # ratioLookupArray = input biomass lookup array, attribute table
    # column = column number of the attribute of interest
    # Output:
    # outArray = array with corresponding values of attribute calculated from biomass
    # Variables:
    # i = current row of biomass array
    # j = current column of biomass array, from biomass raster
    # row = current row of biomass lookup array, attribute table
    # rowPlus = one row ahead of item or current row
    # cellValue = value of the current cell in the biomass array, from biomass raster
    # returnCell = grams of carbon returned from function call

    def biomassConverter(biomassArray,ratioLookupArray,column,maxValue,minValue):
        #creates numpy array with zeros  numpy.zeros()
        #array is the same size as biomass raster array
        rowArraySize, colArraySize = biomassArray.shape

        # create empty output array
        outArray = numpy.zeros( (rowArraySize,colArraySize) )

        rowRatioArray, colRatioArray = ratioLookupArray.shape

        # Loop through all the biomass raster values
        for i in range(rowArraySize):
            for j in range(colArraySize):
                # Loop through all of the biomass values in the lookup chem ratios
                for row in range(rowRatioArray):
                    # index for the next row
                    rowPlus = row + 1
                    cellValue = float(biomassArray[i,j])
                    
                    # Makes sure no cell value is over the maximum biomass allowed
                    if cellValue > maxValue:                   
                        cellValue = float(maxValue)
                    # Make sure no cell value is under the minimum biomass allowed
                    if cellValue < minValue:                   
                        cellValue = float(minValue)

                    # Breaks loop if first element is in lookup chem ratios
                    if cellValue <= ratioLookupArray[row,0]:  
                        returnCell = calLowHighper(ratioLookupArray[row,column],cellValue)
                        outArray[i,j] = returnCell

                        break
                    # Breaks loop if last element in lookup chem ratios
                    if row == (rowRatioArray-1):                         
                        returnCell = calLowHighper(ratioLookupArray[row,column],cellValue)
                        outArray[i,j] = returnCell
                        break
                    
                    # Looks to see if the biomass cellvalue is inbetween the current lookup chem ratio
                    # item and the next row lookup item
                    if cellValue > ratioLookupArray[row,0] and cellValue <= ratioLookupArray[rowPlus,0]:
                        # Return value that is between the two lookup chem ratio rows
                        returnCell = calMidper(ratioLookupArray[rowPlus,column],ratioLookupArray[row,column],           
                                         ratioLookupArray[rowPlus,0],ratioLookupArray[row,0],cellValue)
                        outArray[i,j] = returnCell
        # Return the chem pool array
        return outArray

    #creates numpy array with zeros  numpy.zeros()
    #array is the same size as biomass raster array
    def ageConverter(ageArray,ratioLookupArray,column,maxValue,minValue):
        
        clockStartBiomass = time.perf_counter()

        rowArraySize, colArraySize = ageArray.shape
        
        outArray=numpy.zeros( (rowArraySize,colArraySize) )

        for i in range(rowArraySize):
            for j in range(colArraySize):
                yearRow = int(ageArray[i,j])

                # Change to the year to a max of 400 yo
                if yearRow > maxValue:
                    yearRow = maxValue

                if yearRow < minValue:
                    yearRow = minValue

                # the row number in the lookup ratio file corisponds to age (yr)
                biomassValue = ratioLookupArray[yearRow,0]
                ratioValue = ratioLookupArray[yearRow,column]
                cellValue = biomassValue * ratioValue
                outArray[i,j] = cellValue

        return outArray
    
    ##################################################################################
    # End functions block
    ##################################################################################

    print("Starting the 37 Biomass Ratio convertions!"+'\n')

    ##################################################################################
    # Processing block code
    ##################################################################################
    # Loop once through the driver list to create the carbon ratio ascii rasters first
    for i in driverList:

        # Get output file name
        outName = i[0]
        # Get column name, Unused   
        colName = i[1]
        # Get ratio column number, check that it is not empty first
        # biomass ratio file column number associated with the attribute.
        # Empty sets are nitrogen conversion completed next step
        if i[2] != '':
            ratioCol = int(i[2])
        # Get conversion boolean, FALSE equals file is not a ratio conversion
        conversionOut = i[3]

        # Function call to calculate each of the attributes and create
        # a raster from the returned array
        if conversionOut == 'FALSE':

                # start time clock
            clockStartBiomass = time.perf_counter()
                
            if ageFile != None:
                # For each ratio attribute column determin the ratio of biomass
                # associated with that particular chemestry pool and return an
                # array used to create chem pool raster
                ratioArray = ageConverter(ageArray,ratioLookupArray,ratioCol,maxValue,minValue)
                
            else:   

                # For each ratio attribute column determin the ratio of biomass
                # associated with that particular chemestry pool and return an
                # array used to create chem pool raster
                ratioArray = biomassConverter(biomassArray,ratioLookupArray,ratioCol,maxValue,minValue)

            # Concatinate output dir with output file name
            outName = finalPoolDir + outName
            # Create the chem pool raster
            array2ascii(ratioArray, outName, asciiaoi = None, headerList = buildRatios.header)

            # end time clock
            clockFinishBiomass = time.perf_counter()
            # biomassTime = round((clockFinishBiomass-clockStartBiomass)/60,2)

            # print("Completed: " + outName + " in " + str(biomassTime)+" minutes!"+'\n')
            print_elapsed_mesage(clockStartBiomass, clockFinishBiomass, outName)

    print("Starting the C to N convertions!" + '\n')

    # Second time through the driver list to complete nitrogen ratios last
    # Create Nitrogen grams per square meter from carbon layers
    # Values are carbon to nitrogen ratios from Bob ratio chem file
    for i in driverList:

        # Get output file name
        outName = i[0]
        # Get conversion boolean, TRUE equals file is a nitrogen ratio conversion
        conversionOut = i[3]
        # Carbon filename associated with the nitrogen ratio conversion
        cToNassociateFile = i[4]
        # Get ratio conversion, check that it is not empty first.
        # Empty set are files that don't have a conversion n to c ratio
        if i[5] != '':
            cToNratio = float(i[5])

        if conversionOut == 'TRUE':

            # start time clock
            clockStartBiomass = time.perf_counter()
            
            # Concatinate output dir with input file name
            associateFile = finalPoolDir + cToNassociateFile
            # Get array from ascii raster values from associate carbon raster
            associateArray = ascii2array(associateFile)

            # Create the associated c to n array chemestry pool and return an
            # array used to create chem pool raster
            ratioArray = numpy.divide(associateArray,cToNratio)
            # Concatinate output dir with output file name
            outName = finalPoolDir + outName
            # Create the chem pool raster
            array2ascii(ratioArray, outName, asciiaoi = None, headerList = buildRatios.header)

            # end time clock
            clockFinishBiomass = time.perf_counter()
            raw_diff = clockFinishBiomass-clockStartBiomass
            # biomassTime = round((clockFinishBiomass-clockStartBiomass)/60,2)

            # print("Completed: " + outName + " in " + str(biomassTime)+" minutes!"+'\n')
            print_elapsed_mesage(clockStartBiomass, clockFinishBiomass, outName)

    print("Done!"+'\n')

    ##################################################################################
    # End Processing block
    ##################################################################################


def print_elapsed_mesage(t_start, t_stop, out_name):
    '''
    Generates a unit-appropriate message for the specified out_name elapsed time.
    t_start and t_stop are ASSUMED to be float time values in units of seconds.
    '''
    t_diff = t_stop - t_start
    use_seconds = t_diff < 60
    t_elapsed = t_diff if use_seconds else round(t_diff/60.0, 2)
    t_units = "seconds" if use_seconds else "minutes"
    print("Completed: {0} in {1} {2}\n".format(out_name, t_elapsed, t_units))


if __name__ == "__main__":
    sys.exit(main())
